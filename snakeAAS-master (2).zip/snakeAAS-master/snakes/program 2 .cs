﻿using System;
using System.Collections.Generic;
using System.Text;

namespace snakes
{
    class program_2
    {
    }
}
