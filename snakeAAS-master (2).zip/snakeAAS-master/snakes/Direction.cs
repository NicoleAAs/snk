﻿using System;
using System.Collections.Generic;
using System.Text;

namespace snakes
{ 
    enum Direction
    {
        LEFT,
        RIGHT,
        UP,
        DOWN
    }
}